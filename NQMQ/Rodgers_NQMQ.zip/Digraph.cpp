// Digraph.cpp -- directed graph class
// c. 2017 Andrew Rodgers

#include "Digraph.hpp"

unsigned int Digraph::noVertices()
{
	return numberOfVertices;
}

unsigned int Digraph::noEdges()
{
	return numberOfEdges;
}

void Digraph::resetEdges()
{
	for(int i=0;i<distMatrix.size();i++)
		for(int j=0;j<distMatrix.size();j++) {
			distMatrix[i][j]=9999;	//any sufficiently large interger works but 9999 is convenient
		}
}

void Digraph::addEdge(int source, int dest, int wt)
{
	distMatrix[source][dest]=wt;
	numberOfEdges++;
}

void Digraph::delEdge(int source, int dest)
{
	distMatrix[source][dest]=9999;	//resets distnace between edges to essentially infinity
	distMatrix[dest][source]=9999;
	numberOfEdges--;
}

int Digraph::isEdge(int source, int dest)
{
	return distMatrix[source][dest]!=9999;
}

int Digraph::dijkstra(int source, int dest)
{
	if(source==dest) {
		cout << "SOURCE AND DESTINATION CITY ARE THE SAME -> DISTANCE = 0";
		return -1;
	}
	for(int i=0;i<numberOfVertices;i++)	//set all vertices to NOT_VISITED
		vertex[i]->setStatus(NOT_VISITED);
	int distances[numberOfVertices];	//array of distances to points from source
	std::vector<std::vector<int>> minPath;
	minPath.resize(numberOfVertices);
	for(int i=0;i<numberOfVertices;i++)
		distances[i]=9999;
	distances[source]=0;
	for(int i=0;i<numberOfVertices;i++) {
		int v=source;
		for(int j=0;j<numberOfVertices;j++)
			if(vertex[j]->getStatus()==NOT_VISITED) {
				v=j;
				break;
			}
		for(int k=0;k<numberOfVertices;k++) {
			if((vertex[k]->getStatus()==NOT_VISITED) && (distances[k] < distances[v]))
				v=k;
		}
		vertex[v]->setStatus(VISITED);
		if(distances[v]==9999)
			return -1;
		for(int n=0;n<numberOfVertices;n++) {
			if(isEdge(v,n))
				if(distances[n] > (distances[v] + distMatrix[n][v])) {
					distances[n]=distances[v] + distMatrix[n][v];////
					minPath[n]=minPath[v];	//use shoter path to n if possible
					minPath[n].push_back(v);	//hopefully shouldn't add duplicate vertices to minPath
				}
		}
	}
	for(int i=0;i<numberOfVertices;i++)
		minPath[i].push_back(i);	//add destination to end of all minPath
	for(int i=0;i<minPath[dest].size();i++)
		cout<<vertex[minPath[dest][i]]->getName()<<endl;	//display shortest path
	return distances[dest];
}
